package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

/**
 * Pruebas de la clase Pedido (integran ProductoMenu, ProductoAjustado y Combo).
 *
 * Escenarios:
 * 1. Pedido vacío: precios en 0 y factura solo con encabezado y totales.
 * 2. Pedido con un producto del menú.
 * 3. Pedido con producto del menú + producto ajustado + combo (factura completa).
 * 4. Guardar la factura en un archivo válido y en una ruta inválida.
 */
public class PedidoTest
{
    private Pedido pedido;
    private ProductoMenu corral;
    private ProductoMenu papas;
    private ProductoMenu gaseosa;
    private File archivoTemporal;

    @BeforeEach
    void setUp( ) throws Exception
    {
        pedido = new Pedido( "Juan Pérez", "Calle 19 # 1-30" );
        corral = new ProductoMenu( "corral", 14000 );
        papas = new ProductoMenu( "papas medianas", 5500 );
        gaseosa = new ProductoMenu( "gaseosa", 5000 );
        archivoTemporal = null;
    }

    @AfterEach
    void tearDown( ) throws Exception
    {
        if( archivoTemporal != null && archivoTemporal.exists( ) )
            archivoTemporal.delete( );
    }

    /**
     * Construye un pedido con un producto del menú, un producto ajustado y un combo.
     * Neto = 5000 + (14000 + 2500) + 22050 = 43550 ; IVA = 43550 * 0.19 = 8274.5 -> 8274 ; Total = 51824
     */
    private void llenarPedidoCompleto( )
    {
        ProductoAjustado ajustado = new ProductoAjustado( corral );
        ajustado.agregarIngrediente( new Ingrediente( "queso americano", 2500 ) );
        ajustado.eliminarIngrediente( new Ingrediente( "cebolla", 1000 ) );

        ArrayList<ProductoMenu> items = new ArrayList<ProductoMenu>( );
        items.add( corral );
        items.add( papas );
        items.add( gaseosa );
        Combo combo = new Combo( "combo corral", 0.1, items );

        pedido.agregarProducto( gaseosa );
        pedido.agregarProducto( ajustado );
        pedido.agregarProducto( combo );
    }

    @Test
    void testGetNombreCliente( )
    {
        assertEquals( "Juan Pérez", pedido.getNombreCliente( ), "El nombre del cliente no es el esperado." );
    }

    @Test
    void testIdPedidoConsecutivo( )
    {
        Pedido otro = new Pedido( "Ana", "Carrera 7" );
        Pedido otroMas = new Pedido( "Luis", "Carrera 8" );
        assertEquals( pedido.getIdPedido( ) + 1, otro.getIdPedido( ), "Los identificadores deben ser consecutivos." );
        assertEquals( otro.getIdPedido( ) + 1, otroMas.getIdPedido( ), "Los identificadores deben ser consecutivos." );
    }

    @Test
    void testIdPedidoUnico( )
    {
        Pedido otro = new Pedido( "Ana", "Carrera 7" );
        assertNotEquals( pedido.getIdPedido( ), otro.getIdPedido( ), "Dos pedidos no pueden tener el mismo identificador." );
    }

    @Test
    void testPrecioPedidoVacio( )
    {
        assertEquals( 0, pedido.getPrecioTotalPedido( ), "Un pedido vacío debe costar 0." );
    }

    @Test
    void testPrecioTotalUnProducto( )
    {
        pedido.agregarProducto( corral );
        // 14000 + 19% = 14000 + 2660 = 16660
        assertEquals( 16660, pedido.getPrecioTotalPedido( ), "El precio total debe incluir el IVA." );
    }

    @Test
    void testPrecioTotalVariosProductos( )
    {
        llenarPedidoCompleto( );
        assertEquals( 51824, pedido.getPrecioTotalPedido( ), "El precio total del pedido no es el esperado." );
    }

    @Test
    void testPrecioTotalProductoRepetido( )
    {
        pedido.agregarProducto( gaseosa );
        pedido.agregarProducto( gaseosa );
        // 10000 + 1900 = 11900
        assertEquals( 11900, pedido.getPrecioTotalPedido( ), "Un producto agregado dos veces debe cobrarse dos veces." );
    }

    @Test
    void testGenerarTextoFacturaVacio( )
    {
        String esperado = "Cliente: Juan Pérez\n" + "Dirección: Calle 19 # 1-30\n" + "----------------\n" + "----------------\n" + "Precio Neto:  0\n" + "IVA:          0\n"
                + "Precio Total: 0\n";
        assertEquals( esperado, pedido.generarTextoFactura( ), "La factura de un pedido vacío no es la esperada." );
    }

    @Test
    void testGenerarTextoFacturaCompleta( )
    {
        llenarPedidoCompleto( );
        String esperado = "Cliente: Juan Pérez\n" + "Dirección: Calle 19 # 1-30\n" + "----------------\n"
                // producto del menú
                + "gaseosa\n" + "            5000\n"
                // producto ajustado
                + "corral\n" + "    +queso americano                2500\n" + "    -cebolla\n" + "            16500\n"
                // combo
                + "Combo combo corral\n" + " Descuento: 0.1\n" + "            22050\n"
                // totales
                + "----------------\n" + "Precio Neto:  43550\n" + "IVA:          8274\n" + "Precio Total: 51824\n";
        assertEquals( esperado, pedido.generarTextoFactura( ), "La factura del pedido no es la esperada." );
    }

    @Test
    void testGuardarFactura( ) throws IOException
    {
        llenarPedidoCompleto( );
        archivoTemporal = File.createTempFile( "factura_prueba", ".txt" );

        pedido.guardarFactura( archivoTemporal );

        assertTrue( archivoTemporal.exists( ), "El archivo de la factura debería existir." );
        String contenido = new String( Files.readAllBytes( archivoTemporal.toPath( ) ), Charset.defaultCharset( ) );
        assertEquals( pedido.generarTextoFactura( ), contenido, "El archivo debe contener exactamente el texto de la factura." );
    }

    @Test
    void testGuardarFacturaSobrescribe( ) throws IOException
    {
        archivoTemporal = File.createTempFile( "factura_prueba", ".txt" );
        Files.write( archivoTemporal.toPath( ), "contenido viejo que debe desaparecer".getBytes( Charset.defaultCharset( ) ) );

        pedido.agregarProducto( corral );
        pedido.guardarFactura( archivoTemporal );

        String contenido = new String( Files.readAllBytes( archivoTemporal.toPath( ) ), Charset.defaultCharset( ) );
        assertEquals( pedido.generarTextoFactura( ), contenido, "Guardar la factura debe reemplazar el contenido anterior." );
    }

    @Test
    void testGuardarFacturaRutaInvalida( )
    {
        File archivoInvalido = new File( "./carpeta_que_no_existe_123/sub/factura.txt" );
        assertThrows( FileNotFoundException.class, ( ) -> pedido.guardarFactura( archivoInvalido ),
                "Debería lanzarse FileNotFoundException si no se puede crear el archivo." );
    }
}
