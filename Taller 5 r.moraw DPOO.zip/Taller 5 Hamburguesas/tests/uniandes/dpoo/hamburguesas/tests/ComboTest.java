package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

/**
 * Pruebas unitarias de la clase Combo.
 *
 * Escenario: "combo corral" = corral (14000) + papas medianas (5500) + gaseosa (5000) con 10% de descuento.
 * Suma sin descuento = 24500, precio esperado = 24500 * 0.9 = 22050.
 */
public class ComboTest
{
    private ArrayList<ProductoMenu> items;
    private Combo comboCorral;

    @BeforeEach
    void setUp( ) throws Exception
    {
        items = new ArrayList<ProductoMenu>( );
        items.add( new ProductoMenu( "corral", 14000 ) );
        items.add( new ProductoMenu( "papas medianas", 5500 ) );
        items.add( new ProductoMenu( "gaseosa", 5000 ) );
        comboCorral = new Combo( "combo corral", 0.1, items );
    }

    @AfterEach
    void tearDown( ) throws Exception
    {
    }

    @Test
    void testGetNombre( )
    {
        assertEquals( "combo corral", comboCorral.getNombre( ), "El nombre del combo no es el esperado." );
    }

    @Test
    void testGetPrecio( )
    {
        assertEquals( 22050, comboCorral.getPrecio( ), "El precio debe ser la suma de los productos menos el descuento." );
    }

    @Test
    void testGetPrecioDescuentoDecimal( )
    {
        // 24000 + 5500 + 5000 = 34500 ; 34500 * (1 - 0.095) = 31222.5 -> 31222
        ArrayList<ProductoMenu> itemsEspecial = new ArrayList<ProductoMenu>( );
        itemsEspecial.add( new ProductoMenu( "especial", 24000 ) );
        itemsEspecial.add( new ProductoMenu( "papas medianas", 5500 ) );
        itemsEspecial.add( new ProductoMenu( "gaseosa", 5000 ) );
        Combo especial = new Combo( "combo especial", 0.095, itemsEspecial );
        assertEquals( 31222, especial.getPrecio( ), "El precio del combo con descuento de 9.5% no es el esperado." );
    }

    @Test
    void testGetPrecioSinDescuento( )
    {
        Combo sinDescuento = new Combo( "combo normal", 0, items );
        assertEquals( 24500, sinDescuento.getPrecio( ), "Con descuento 0 el precio debe ser la suma de los productos." );
    }

    @Test
    void testGetPrecioDescuentoTotal( )
    {
        Combo gratis = new Combo( "combo gratis", 1, items );
        assertEquals( 0, gratis.getPrecio( ), "Con descuento del 100% el precio debe ser 0." );
    }

    @Test
    void testGetPrecioComboVacio( )
    {
        Combo vacio = new Combo( "combo vacio", 0.1, new ArrayList<ProductoMenu>( ) );
        assertEquals( 0, vacio.getPrecio( ), "Un combo sin productos debe costar 0." );
    }

    @Test
    void testCopiaDefensivaDeItems( )
    {
        // Modificar la lista original después de crear el combo no debe afectar al combo
        items.add( new ProductoMenu( "papas grandes", 6900 ) );
        assertEquals( 22050, comboCorral.getPrecio( ), "El combo no debe verse afectado por cambios en la lista original." );
    }

    @Test
    void testGenerarTextoFactura( )
    {
        String esperado = "Combo combo corral\n" + " Descuento: 0.1\n" + "            22050\n";
        assertEquals( esperado, comboCorral.generarTextoFactura( ), "El texto de la factura no es el esperado." );
    }
}
