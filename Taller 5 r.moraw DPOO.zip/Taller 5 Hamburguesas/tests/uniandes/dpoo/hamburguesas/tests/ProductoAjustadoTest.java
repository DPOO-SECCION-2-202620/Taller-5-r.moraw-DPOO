package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

/**
 * Pruebas unitarias de la clase ProductoAjustado.
 *
 * Escenarios:
 * 1. Producto ajustado sin modificaciones (precio = precio base).
 * 2. Producto con ingredientes agregados (precio = base + adicionales, el mismo ingrediente puede repetirse).
 * 3. Producto con ingredientes eliminados (eliminar NO reduce el precio).
 * 4. Producto con agregados y eliminados a la vez (texto de factura completo).
 */
public class ProductoAjustadoTest
{
    private ProductoMenu corral;
    private Ingrediente queso;
    private Ingrediente tocineta;
    private Ingrediente cebolla;
    private ProductoAjustado ajustado;

    @BeforeEach
    void setUp( ) throws Exception
    {
        corral = new ProductoMenu( "corral", 14000 );
        queso = new Ingrediente( "queso americano", 2500 );
        tocineta = new Ingrediente( "tocineta express", 2500 );
        cebolla = new Ingrediente( "cebolla", 1000 );
        ajustado = new ProductoAjustado( corral );
    }

    @AfterEach
    void tearDown( ) throws Exception
    {
    }

    @Test
    void testGetNombre( )
    {
        assertEquals( "corral", ajustado.getNombre( ), "El nombre debe ser el del producto base." );
    }

    @Test
    void testGetPrecioSinAjustes( )
    {
        assertEquals( 14000, ajustado.getPrecio( ), "Sin ajustes, el precio debe ser el del producto base." );
    }

    @Test
    void testGetPrecioConAgregados( )
    {
        ajustado.agregarIngrediente( queso );
        ajustado.agregarIngrediente( tocineta );
        assertEquals( 19000, ajustado.getPrecio( ), "El precio debe incluir el costo de los ingredientes agregados." );
    }

    @Test
    void testGetPrecioConIngredienteRepetido( )
    {
        ajustado.agregarIngrediente( queso );
        ajustado.agregarIngrediente( queso );
        assertEquals( 19000, ajustado.getPrecio( ), "Un ingrediente agregado dos veces debe cobrarse dos veces." );
    }

    @Test
    void testGetPrecioConEliminados( )
    {
        ajustado.eliminarIngrediente( cebolla );
        assertEquals( 14000, ajustado.getPrecio( ), "Eliminar ingredientes no debe reducir el precio." );
    }

    @Test
    void testGetPrecioConAgregadosYEliminados( )
    {
        ajustado.agregarIngrediente( queso );
        ajustado.eliminarIngrediente( cebolla );
        assertEquals( 16500, ajustado.getPrecio( ), "Solo los ingredientes agregados deben sumar al precio." );
    }

    @Test
    void testNoModificaProductoBase( )
    {
        ajustado.agregarIngrediente( queso );
        assertEquals( 14000, corral.getPrecio( ), "Ajustar un producto no debe cambiar el precio del producto base." );
    }

    @Test
    void testGenerarTextoFacturaSinAjustes( )
    {
        String esperado = "corral\n" + "            14000\n";
        assertEquals( esperado, ajustado.generarTextoFactura( ), "El texto de la factura no es el esperado." );
    }

    @Test
    void testGenerarTextoFacturaConAjustes( )
    {
        ajustado.agregarIngrediente( queso );
        ajustado.eliminarIngrediente( cebolla );

        String esperado = "corral\n" + "    +queso americano                2500\n" + "    -cebolla\n" + "            16500\n";
        assertEquals( esperado, ajustado.generarTextoFactura( ), "El texto de la factura no es el esperado." );
    }

    @Test
    void testGenerarTextoFacturaNoUsaToStringDelObjeto( )
    {
        String factura = ajustado.generarTextoFactura( );
        assertFalse( factura.contains( "ProductoMenu@" ), "La factura no debe mostrar la representación interna del objeto." );
        assertTrue( factura.startsWith( "corral" ), "La factura debe empezar con el nombre del producto base." );
    }
}
