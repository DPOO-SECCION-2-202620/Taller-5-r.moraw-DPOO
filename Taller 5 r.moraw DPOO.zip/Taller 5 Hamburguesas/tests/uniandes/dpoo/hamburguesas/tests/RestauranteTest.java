package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.excepciones.IngredienteRepetidoException;
import uniandes.dpoo.hamburguesas.excepciones.NoHayPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.excepciones.ProductoFaltanteException;
import uniandes.dpoo.hamburguesas.excepciones.ProductoRepetidoException;
import uniandes.dpoo.hamburguesas.excepciones.YaHayUnPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.Restaurante;

/**
 * Pruebas de integración de la clase Restaurante.
 *
 * Escenarios de carga (archivos en data/ y data/pruebas/):
 * 1. Archivos reales del restaurante (data/).
 * 2. Archivos pequeños y controlados, con líneas vacías (data/pruebas/*_ok.txt).
 * 3. Ingrediente repetido, producto repetido, combo repetido, combo con producto faltante,
 *    precio con formato inválido y archivo inexistente.
 *
 * Escenarios de pedidos:
 * 4. Iniciar pedido, iniciar un segundo pedido (excepción), cerrar sin pedido (excepción),
 *    cerrar y guardar (archivo creado, pedido en el histórico, pedido en curso = null).
 */
public class RestauranteTest
{
    private static final String CARPETA_PRUEBAS = "./data/pruebas/";

    private Restaurante restaurante;

    /**
     * Archivos de factura creados durante una prueba, para borrarlos en tearDown
     */
    private ArrayList<File> facturasCreadas;

    @BeforeEach
    void setUp( ) throws Exception
    {
        restaurante = new Restaurante( );
        facturasCreadas = new ArrayList<File>( );
    }

    @AfterEach
    void tearDown( ) throws Exception
    {
        for( File f : facturasCreadas )
        {
            if( f.exists( ) )
                f.delete( );
        }
    }

    private File archivoPrueba( String nombre )
    {
        return new File( CARPETA_PRUEBAS + nombre );
    }

    private void cargarArchivosOk( ) throws Exception
    {
        restaurante.cargarInformacionRestaurante( archivoPrueba( "ingredientes_ok.txt" ), archivoPrueba( "menu_ok.txt" ), archivoPrueba( "combos_ok.txt" ) );
    }

    private File archivoFactura( Pedido p )
    {
        return new File( "./facturas/factura_" + p.getIdPedido( ) + ".txt" );
    }

    // ***************************************
    // Estado inicial
    // ***************************************

    @Test
    void testRestauranteVacio( )
    {
        assertNotNull( restaurante.getIngredientes( ), "La lista de ingredientes no debe ser null." );
        assertNotNull( restaurante.getMenuBase( ), "El menú base no debe ser null." );
        assertNotNull( restaurante.getMenuCombos( ), "El menú de combos no debe ser null." );
        assertNotNull( restaurante.getPedidos( ), "La lista de pedidos no debe ser null." );
        assertEquals( 0, restaurante.getIngredientes( ).size( ) );
        assertEquals( 0, restaurante.getMenuBase( ).size( ) );
        assertEquals( 0, restaurante.getMenuCombos( ).size( ) );
        assertEquals( 0, restaurante.getPedidos( ).size( ) );
        assertNull( restaurante.getPedidoEnCurso( ), "Al inicio no debe haber pedido en curso." );
    }

    // ***************************************
    // Carga de información
    // ***************************************

    @Test
    void testCargarArchivosReales( ) throws Exception
    {
        restaurante.cargarInformacionRestaurante( new File( "./data/ingredientes.txt" ), new File( "./data/menu.txt" ), new File( "./data/combos.txt" ) );

        assertEquals( 15, restaurante.getIngredientes( ).size( ), "Deberían cargarse 15 ingredientes." );
        assertEquals( 22, restaurante.getMenuBase( ).size( ), "Deberían cargarse 22 productos." );
        assertEquals( 4, restaurante.getMenuCombos( ).size( ), "Deberían cargarse 4 combos." );
    }

    @Test
    void testCargarIngredientes( ) throws Exception
    {
        cargarArchivosOk( );
        ArrayList<Ingrediente> ingredientes = restaurante.getIngredientes( );

        assertEquals( 3, ingredientes.size( ), "Las líneas vacías deben ignorarse." );
        assertEquals( "lechuga", ingredientes.get( 0 ).getNombre( ) );
        assertEquals( 1000, ingredientes.get( 0 ).getCostoAdicional( ) );
        assertEquals( "queso americano", ingredientes.get( 2 ).getNombre( ) );
        assertEquals( 2500, ingredientes.get( 2 ).getCostoAdicional( ) );
    }

    @Test
    void testCargarMenu( ) throws Exception
    {
        cargarArchivosOk( );
        ArrayList<ProductoMenu> menu = restaurante.getMenuBase( );

        assertEquals( 4, menu.size( ), "Las líneas vacías deben ignorarse." );
        assertEquals( "corral", menu.get( 0 ).getNombre( ) );
        assertEquals( 14000, menu.get( 0 ).getPrecio( ) );
        assertEquals( "especial", menu.get( 3 ).getNombre( ) );
        assertEquals( 24000, menu.get( 3 ).getPrecio( ) );
    }

    @Test
    void testCargarCombos( ) throws Exception
    {
        cargarArchivosOk( );
        ArrayList<Combo> combos = restaurante.getMenuCombos( );

        assertEquals( 2, combos.size( ), "Las líneas vacías deben ignorarse." );

        Combo corral = combos.get( 0 );
        assertEquals( "combo corral", corral.getNombre( ) );
        // (14000 + 5500 + 5000) * 0.90 = 22050
        assertEquals( 22050, corral.getPrecio( ), "El descuento del combo no se aplicó correctamente." );

        Combo especial = combos.get( 1 );
        assertEquals( "combo especial", especial.getNombre( ) );
        // (24000 + 5500 + 5000) * 0.905 = 31222.5 -> 31222
        assertEquals( 31222, especial.getPrecio( ), "El descuento decimal (9.5%) no se aplicó correctamente." );
    }

    @Test
    void testCargarIngredienteRepetido( )
    {
        IngredienteRepetidoException e = assertThrows( IngredienteRepetidoException.class,
                ( ) -> restaurante.cargarInformacionRestaurante( archivoPrueba( "ingredientes_repetidos.txt" ), archivoPrueba( "menu_ok.txt" ),
                        archivoPrueba( "combos_ok.txt" ) ),
                "Debería lanzarse IngredienteRepetidoException." );
        assertEquals( "El ingrediente lechuga está repetido", e.getMessage( ) );
    }

    @Test
    void testCargarProductoRepetido( )
    {
        ProductoRepetidoException e = assertThrows( ProductoRepetidoException.class,
                ( ) -> restaurante.cargarInformacionRestaurante( archivoPrueba( "ingredientes_ok.txt" ), archivoPrueba( "menu_repetido.txt" ),
                        archivoPrueba( "combos_ok.txt" ) ),
                "Debería lanzarse ProductoRepetidoException." );
        assertEquals( "El producto corral está repetido", e.getMessage( ) );
    }

    @Test
    void testCargarComboRepetido( )
    {
        ProductoRepetidoException e = assertThrows( ProductoRepetidoException.class,
                ( ) -> restaurante.cargarInformacionRestaurante( archivoPrueba( "ingredientes_ok.txt" ), archivoPrueba( "menu_ok.txt" ),
                        archivoPrueba( "combos_repetidos.txt" ) ),
                "Debería lanzarse ProductoRepetidoException para un combo repetido." );
        assertEquals( "El producto combo corral está repetido", e.getMessage( ) );
    }

    @Test
    void testCargarComboConProductoFaltante( )
    {
        ProductoFaltanteException e = assertThrows( ProductoFaltanteException.class,
                ( ) -> restaurante.cargarInformacionRestaurante( archivoPrueba( "ingredientes_ok.txt" ), archivoPrueba( "menu_ok.txt" ),
                        archivoPrueba( "combos_producto_faltante.txt" ) ),
                "Debería lanzarse ProductoFaltanteException." );
        assertEquals( "El producto malteada no aparece en la información del restaurante", e.getMessage( ) );
    }

    @Test
    void testCargarPrecioInvalido( )
    {
        assertThrows( NumberFormatException.class,
                ( ) -> restaurante.cargarInformacionRestaurante( archivoPrueba( "ingredientes_ok.txt" ), archivoPrueba( "menu_precio_invalido.txt" ),
                        archivoPrueba( "combos_ok.txt" ) ),
                "Debería lanzarse NumberFormatException si un precio no es un número." );
    }

    @Test
    void testCargarArchivoInexistente( )
    {
        assertThrows( FileNotFoundException.class,
                ( ) -> restaurante.cargarInformacionRestaurante( archivoPrueba( "no_existe.txt" ), archivoPrueba( "menu_ok.txt" ),
                        archivoPrueba( "combos_ok.txt" ) ),
                "Debería lanzarse FileNotFoundException si el archivo no existe." );
    }

    // ***************************************
    // Pedidos
    // ***************************************

    @Test
    void testIniciarPedido( ) throws Exception
    {
        restaurante.iniciarPedido( "Juan", "Calle 19" );

        Pedido enCurso = restaurante.getPedidoEnCurso( );
        assertNotNull( enCurso, "Debería haber un pedido en curso." );
        assertEquals( "Juan", enCurso.getNombreCliente( ) );
    }

    @Test
    void testIniciarPedidoConPedidoEnCurso( ) throws Exception
    {
        restaurante.iniciarPedido( "Juan", "Calle 19" );

        YaHayUnPedidoEnCursoException e = assertThrows( YaHayUnPedidoEnCursoException.class, ( ) -> restaurante.iniciarPedido( "Ana", "Carrera 7" ),
                "Debería lanzarse YaHayUnPedidoEnCursoException." );
        assertEquals( "Ya existe un pedido en curso, para el cliente Juan así que no se puede crear un pedido para Ana", e.getMessage( ) );
        assertEquals( "Juan", restaurante.getPedidoEnCurso( ).getNombreCliente( ), "El pedido en curso no debe cambiar." );
    }

    @Test
    void testCerrarSinPedidoEnCurso( )
    {
        NoHayPedidoEnCursoException e = assertThrows( NoHayPedidoEnCursoException.class, ( ) -> restaurante.cerrarYGuardarPedido( ),
                "Debería lanzarse NoHayPedidoEnCursoException." );
        assertEquals( "Actualmente no hay un pedido en curso", e.getMessage( ) );
    }

    @Test
    void testCerrarYGuardarPedido( ) throws Exception
    {
        cargarArchivosOk( );
        restaurante.iniciarPedido( "Juan", "Calle 19" );
        Pedido pedido = restaurante.getPedidoEnCurso( );
        pedido.agregarProducto( restaurante.getMenuBase( ).get( 0 ) );
        pedido.agregarProducto( restaurante.getMenuCombos( ).get( 0 ) );
        File factura = archivoFactura( pedido );
        facturasCreadas.add( factura );

        restaurante.cerrarYGuardarPedido( );

        assertNull( restaurante.getPedidoEnCurso( ), "Después de cerrar no debe haber pedido en curso." );
        assertEquals( 1, restaurante.getPedidos( ).size( ), "El pedido cerrado debe quedar en el histórico." );
        assertSame( pedido, restaurante.getPedidos( ).get( 0 ), "El pedido del histórico debe ser el que se cerró." );

        assertTrue( factura.exists( ), "Debe existir el archivo " + factura.getPath( ) );
        String contenido = new String( Files.readAllBytes( factura.toPath( ) ), Charset.defaultCharset( ) );
        assertEquals( pedido.generarTextoFactura( ), contenido, "El archivo debe contener la factura del pedido." );
    }

    @Test
    void testVariosPedidosSeguidos( ) throws Exception
    {
        restaurante.iniciarPedido( "Juan", "Calle 19" );
        Pedido p1 = restaurante.getPedidoEnCurso( );
        facturasCreadas.add( archivoFactura( p1 ) );
        restaurante.cerrarYGuardarPedido( );

        restaurante.iniciarPedido( "Ana", "Carrera 7" );
        Pedido p2 = restaurante.getPedidoEnCurso( );
        facturasCreadas.add( archivoFactura( p2 ) );
        restaurante.cerrarYGuardarPedido( );

        assertEquals( 2, restaurante.getPedidos( ).size( ), "Ambos pedidos deben quedar en el histórico." );
        assertNotEquals( p1.getIdPedido( ), p2.getIdPedido( ) );
        assertTrue( archivoFactura( p1 ).exists( ) );
        assertTrue( archivoFactura( p2 ).exists( ) );
    }
}
